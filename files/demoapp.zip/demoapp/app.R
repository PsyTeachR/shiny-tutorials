library(shiny)
library(ggplot2)

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("My Demo App"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput(inputId = "bins",
                        label = "Number of bins:",
                        min = 5,
                        max = 100,
                        value = 10),
            sliderInput(inputId = "binwidth",
                        label = "Width of your bins:",
                        min = 1,
                        max = 10,
                        value = 5,
                        step = 0.5)
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput(outputId = "distPlot"),
           tableOutput(outputId = "dataTable")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    output$distPlot <- renderPlot({
        ggplot(data = faithful, 
               mapping = aes(x = waiting)
               ) +
            geom_histogram(binwidth = input$binwidth,
                           colour = "black",
                           fill = "red")
        
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
