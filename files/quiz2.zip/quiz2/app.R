## libraries ----
suppressPackageStartupMessages({
    library(shiny)
    library(shinyjs)
    library(shinydashboard)
})

## functions ----

source("R/func.R") # put long functions in external files

## tabs ----

# you can put complex tabs in separate files and source them
source("ui/main_tab.R")
source("ui/info_tab.R")


# if the header and/or sidebar get too complex, 
# put them in external files and uncomment below 
# source("ui/header.R") # defines the `header`
# source("ui/sidebar.R") # defines the `sidebar`


## UI ----
ui <- dashboardPage(
    skin = "purple",
    # header, # if sourced above
    dashboardHeader(title = "Quiz"),
    # sidebar, # if sourced above
    dashboardSidebar(
        # https://fontawesome.com/icons?d=gallery&m=free
        sidebarMenu(
            id = "tabs",
            menuItem("Main", tabName = "main_tab",
                     icon = icon("home")),
            menuItem("Info", tabName = "info_tab",
                     icon = icon("angellist"))
        )
    ),
    dashboardBody(
        shinyjs::useShinyjs(),
        tags$head(
            tags$link(rel = "stylesheet", type = "text/css", href = "custom.css"), # links to www/custom.css
            tags$script(src = "custom.js") # links to www/custom.js
        ),
        tabItems(
            main_tab,
            info_tab
        )
    )
)


## server ----
server <- function(input, output, session) {
    
    Q <- function(Q = 1, add = "r") {
        qname <- paste0("Q", Q, "_", add)
        debug_msg(qname, input[[qname]])
        
        # set selected outline and remove others
        c_levels <- c("r", "o", "y", "g", "b", "p")
        ids <- paste0("Q", Q, "_", c_levels)
        sapply(ids, removeClass, class = "selected")
        addClass(qname, "selected")
        
        # code to move to next Q
    }
    
    observeEvent(input$Q1_r, { Q(1, "r") })
    observeEvent(input$Q1_o, { Q(1, "o") })
    observeEvent(input$Q1_y, { Q(1, "y") })
    observeEvent(input$Q1_g, { Q(1, "g") })
    observeEvent(input$Q1_b, { Q(1, "b") })
    observeEvent(input$Q1_p, { Q(1, "p") })
    
    observeEvent(input$Q2_r, { Q(2, "r") })
    observeEvent(input$Q2_o, { Q(2, "o") })
    observeEvent(input$Q2_y, { Q(2, "y") })
    observeEvent(input$Q2_g, { Q(2, "g") })
    observeEvent(input$Q2_b, { Q(2, "b") })
    observeEvent(input$Q2_p, { Q(2, "p") })
    
    observeEvent(input$Q3_r, { Q(3, "r") })
    observeEvent(input$Q3_o, { Q(3, "o") })
    observeEvent(input$Q3_y, { Q(3, "y") })
    observeEvent(input$Q3_g, { Q(3, "g") })
    observeEvent(input$Q3_b, { Q(3, "b") })
    observeEvent(input$Q3_p, { Q(3, "p") })

} 

shinyApp(ui, server)