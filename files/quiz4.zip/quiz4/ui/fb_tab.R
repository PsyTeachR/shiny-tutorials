# fb_tab ----
fb_tab <- tabItem(
  tabName = "fb_tab",
  h2("Feedback"),
  p("All colours are great. This is the distribution of your favourites."),
  plotOutput("my_plot"),
  actionButton("save_data", "Add My data"),
  plotOutput("others_plot")
)
