## libraries ----
suppressPackageStartupMessages({
    library(shiny)
    library(shinyjs)
    library(shinydashboard)
})

## functions ----

source("R/func.R") # put long functions in external files

img_btn <- function(id, img) {
    tags$button(
        id = id,
        type = "button",
        class = "btn action-button img-btn",
        img(src = img, width = "300px")
    )
}

## tabs ----

# you can put complex tabs in separate files and source them
#source("ui/main_tab.R")
#source("ui/info_tab.R")

# main_tab ----
main_tab <- tabItem(
    tabName = "main_tab",
    box(id = "Q1", width = 12, 
        title = "What is your favourite flower?",
        collapsible = T, collapsed = F,
        img_btn("Q1_r", "img/flower.jpg"),
        img_btn("Q1_o", "img/sunflower-1627193_640.jpg"),
        img_btn("Q1_y", "img/flower.jpg"),
        img_btn("Q1_g", "img/flower.jpg"),
        img_btn("Q1_b", "img/flower.jpg"),
        img_btn("Q1_p", "img/flower.jpg")
    ),
    box(id = "Q2", width = 12,
        title = "What is your favourite landscape?",
        collapsible = T, collapsed = T
    ),
    box(id = "Q3", width = 12,
        title = "What is your favourite animal?",
        collapsible = T, collapsed = T
    ),
    box(id = "Q4", width = 12,
        title = "What is your favourite colour?",
        collapsible = T, collapsed = T
    ),
    actionButton("view_feedback", "Submit")
)

# info_tab ----
info_tab <- tabItem(
    tabName = "info_tab",
    h2("Info"),
    HTML('Image by <a href="https://pixabay.com/users/ulleo-1834854/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1627193">Ulrike Leone</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1627193">Pixabay</a>')
)


# if the header and/or sidebar get too complex, 
# put them in external files and uncomment below 
# source("ui/header.R") # defines the `header`
# source("ui/sidebar.R") # defines the `sidebar`


## UI ----
ui <- dashboardPage(
    skin = "purple",
    # header, # if sourced above
    dashboardHeader(title = "Quiz"),
    # sidebar, # if sourced above
    dashboardSidebar(
        # https://fontawesome.com/icons?d=gallery&m=free
        sidebarMenu(
            id = "tabs",
            menuItem("Main", tabName = "main_tab",
                     icon = icon("home")),
            menuItem("Info", tabName = "info_tab",
                     icon = icon("angellist"))
        )
    ),
    dashboardBody(
        shinyjs::useShinyjs(),
        tags$head(
            tags$link(rel = "stylesheet", type = "text/css", href = "custom.css"), # links to www/custom.css
            tags$script(src = "custom.js") # links to www/custom.js
        ),
        tabItems(
            main_tab,
            info_tab
        )
    )
)


## server ----
server <- function(input, output, session) {
    observeEvent(input$show_flower, {
        debug_msg("show_flower", input$show_flower)
        runjs("openBox('flower_box');")
    })
    
    observeEvent(input$hide_flower, {
        debug_msg("hide_flower", input$hide_flower)
        runjs("closeBox('flower_box');")
    })
} 

shinyApp(ui, server)