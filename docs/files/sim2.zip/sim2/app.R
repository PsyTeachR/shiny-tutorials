## libraries ----
suppressPackageStartupMessages({
    library(shiny)
    library(shinyjs)
    library(shinydashboard)
    library(ggplot2)
})

## functions ----

# source("R/func.R") # put long functions in external files

# display debugging messages in R if local, 
# or in the console log if remote
debug_msg <- function(...) {
    is_local <- Sys.getenv('SHINY_PORT') == ""
    txt <- paste(...)
    if (is_local) {
        message(txt)
    } else {
        shinyjs::logjs(txt)
    }
}

## tabs ----

# you can put complex tabs in separate files and source them
#source("ui/main_tab.R")
#source("ui/info_tab.R")

## main_tab ----
main_tab <- tabItem(
    tabName = "main_tab",
    p("This app will teach you about distributions.")
)

## unif_tab ----
unif_tab <- tabItem(
    tabName = "unif_tab",
    h2("Uniform Distribution"),
    fluidRow(
        column(width = 4,
               numericInput("unif_n", "N", value = 10, min = 1, max = 10000, step = 1),
               numericInput("unif_min", "Minimum", value = 0),
               numericInput("unif_max", "Maximum", value = 1),
               actionButton("unif_submit", "Simulate")
        ),
        column(width = 8,
               plotOutput("unif_plot")
        )
    )
)

## norm_tab ----
norm_tab <- tabItem(
    tabName = "norm_tab",
    h2("Normal Distribution"),
    fluidRow(
        column(width = 4,
                numericInput("norm_n", "N", value = 10, min = 1, max = 10000, step = 1),
                numericInput("norm_mean", "Mean", value = 0),
                numericInput("norm_sd", "SD", value = 1),
                actionButton("norm_submit", "Simulate")
        ),
        column(width = 8,
               plotOutput("norm_plot")
        )
    )
)


# if the header and/or sidebar get too complex, 
# put them in external files and uncomment below 
# source("ui/header.R") # defines the `header`
# source("ui/sidebar.R") # defines the `sidebar`


## UI ----
ui <- dashboardPage(
    skin = "red",
    # header, # if sourced above
    dashboardHeader(title = "Simulate"),
    # sidebar, # if sourced above
    dashboardSidebar(
        # https://fontawesome.com/icons?d=gallery&m=free
        sidebarMenu(
            id = "tabs",
            menuItem("Main", tabName = "main_tab",
                     icon = icon("home")),
            menuItem("Uniform", tabName = "unif_tab",
                     icon = icon("ruler-horizontal")),
            menuItem("Normal", tabName = "norm_tab",
                     icon = icon("bell"))
        )
    ),
    dashboardBody(
        shinyjs::useShinyjs(),
        tags$head(
            tags$link(rel = "stylesheet", type = "text/css", href = "custom.css"), # links to www/custom.css
            tags$script(src = "custom.js") # links to www/custom.js
        ),
        tabItems(
            main_tab,
            unif_tab,
            norm_tab
        )
    )
)


## server ----
server <- function(input, output, session) {
    # unif_submit ----
    observeEvent(input$unif_submit, {
        debug_msg("unif_submit: ", input$unif_submit)
        # input check
        debug_msg("unif_n: ", input$unif_n)
        is_numeric <- is.numeric(input$unif_n)
        is_int <- as.integer(input$unif_n) == input$unif_n
        is_pos <- input$unif_n >= 1
        if (!is_numeric || !is_int || !is_pos) {
            showNotification("Bad n")
            return()
        }
        
        debug_msg("unif_min: ", input$unif_min)
        is_numeric <- is.numeric(input$unif_min)
        if (!is_numeric) {
            showNotification("Bad min")
            return()
        }
        
        debug_msg("unif_max: ", input$unif_max)
        is_numeric <- is.numeric(input$unif_max)
        is_bigger <- input$unif_max > input$unif_min
        if (!is_numeric || !is_bigger) {
            showNotification("Bad max")
            return()
        }
        
        # simulate data
        data <- runif(
            n = input$unif_n,
            min = input$unif_min,
            max = input$unif_max
        )
        df <- data.frame(
            x = data
        )
        # draw plot
        p <- ggplot(df, aes(x = x)) +
            geom_histogram(bins = 20) +
            xlim(input$unif_min, input$unif_max)
        
        output$unif_plot <- renderPlot(p)
    })
    
    # norm_submit ----
    observeEvent(input$norm_submit, {
        debug_msg("norm_submit: ", input$norm_submit)
        # input check
        
        # simulate data
        data <- rnorm(
            n = input$norm_n,
            mean = input$norm_mean,
            sd = input$norm_sd
        )
        df <- data.frame(
            x = data
        )
        # draw plot
        xmin <- input$norm_mean - (4*input$norm_sd)
        xmax <- input$norm_mean + (4*input$norm_sd)
        p <- ggplot(df, aes(x = x)) +
            geom_density() +
            stat_function(fun = dnorm, 
                          n = 101, 
                          color = "red",
                          args = list(mean = input$norm_mean,
                                      sd = input$norm_sd)
                          ) +
            scale_x_continuous(n.breaks = 9, limits = c(xmin, xmax))
        
        output$norm_plot <- renderPlot(p)
    })
} 

shinyApp(ui, server)